var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":[],"propsByKey":{}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var death = 0;
var wall1 = createSprite(200, 120, 400, 5);
wall1.shapeColor = "black";
var wall2 = createSprite(200, 260, 400, 5);
wall2.shapeColor = "black";
var player = createSprite(20, 195, 10, 10);
player.shapeColor = "darkblue";
var enemy1 = createSprite(110, 135, 10, 10);
enemy1.shapeColor = "red";
var enemy2 = createSprite(220, 130, 10, 10);
enemy2.shapeColor = "red";
var enemy3 = createSprite(165, 250, 10, 10);
enemy3.shapeColor = "red";
var enemy4 = createSprite(275, 250, 10, 10);
enemy4.shapeColor = "red";
enemy1.velocityY = 7;
enemy2.velocityY = 7;
enemy3.velocityY = -7;
enemy4.velocityY = -7;
function draw() {
  background("white");
  text("Deaths: " + death, 200, 100);
  strokeWeight(0);
  fill("lightblue");
  rect(0, 120, 51, 140);
  fill("yellow");
  rect(350, 120, 51, 140);
  enemy1.bounceOff(wall1);
  enemy1.bounceOff(wall2);
  enemy2.bounceOff(wall1);
  enemy2.bounceOff(wall2);
  enemy3.bounceOff(wall1);
  enemy3.bounceOff(wall2);
  enemy4.bounceOff(wall1);
  enemy4.bounceOff(wall2);
  if (keyDown("right")) {
    player.x = player.x + 2;
  }
  if (keyDown("left")) {
    player.x = player.x - 2;
  }
  if(
     player.isTouching(enemy1)||
     player.isTouching(enemy2)||
     player.isTouching(enemy3)||
     player.isTouching(enemy4))
  {
    player.x = 20;
    player.y = 195;
    death = death + 1;
  }
  
  drawSprites();
    ;
  }
  ;

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
